package org.rest.Controller;

import java.io.IOException;

import org.json.simple.JSONObject;
import org.rest.Services.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
public class CustomerInformationController {

	@Autowired
	CustomerService customerService;
	
	private static Logger L = LoggerFactory.getLogger(CustomerInformationController.class);
	
	@RequestMapping(value = "/customers", method = RequestMethod.GET)
	public ResponseEntity<?> getRepositoryContent() throws IOException {
		
		ResponseEntity<?> responseEntity = null;
		JSONObject result = null;
		try {
			result = customerService.getCustomers();
			if(result !=null) {
				responseEntity = new ResponseEntity<Object>(result, HttpStatus.OK);
			}
			else {
				responseEntity = new ResponseEntity<Object>(" ", HttpStatus.NO_CONTENT);
				throw new Exception("Something went wrong");
			}
			
		}catch(Exception e) {
			L.info("Some exception occured "+e);
		}
		
		return responseEntity;
	}
	
	
	@RequestMapping(value = "/customers/{customerID}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getRepositoryContent(
			@PathVariable(value = "customerID", required = true) String customerID) throws IOException {
		
		ResponseEntity<?> responseEntity = null;
		JSONObject result = null;
		try {
			result = customerService.getCustomerDetails(customerID);
			if(result !=null) {
				responseEntity = new ResponseEntity<Object>(result, HttpStatus.OK);
			}
			else {
				responseEntity = new ResponseEntity<Object>(" ", HttpStatus.NO_CONTENT);
				throw new Exception("Something went wrong");
			}
			
		}catch(Exception e) {
			L.info("Some exception occured "+e); 
		}
		
		return responseEntity;
	}

}
