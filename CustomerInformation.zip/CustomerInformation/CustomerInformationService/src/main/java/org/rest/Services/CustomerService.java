package org.rest.Services;

import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

	private static Logger L = LoggerFactory.getLogger(CustomerService.class);
	String path = "C:/Users/yash2/Desktop/CustomerInformation/CustomerInformationWeb/src/main/resources/dataset.json";

	public JSONObject getCustomerDetails(String id) {

		JSONParser parser = new JSONParser();
		JSONObject response = null;
		JSONObject customerJSON;

		try {
			customerJSON = (JSONObject) parser.parse(new FileReader(path));
			JSONObject customerDetails = (JSONObject) customerJSON.get(id);
			response = customerDetails;
		} catch (IOException | ParseException e) {
			L.info("Some exception occured");
		}
		return response;
	}

	public JSONObject getCustomers() {

		JSONParser parser = new JSONParser();
		JSONObject response = null;
		JSONObject customerJSON;

		try {
			customerJSON = (JSONObject) parser.parse(new FileReader(path));
			response = customerJSON;
		} catch (IOException | ParseException e) {
			L.info("Some exception occured");
		}
		return response;
	}
}