package org.rest.DTO;

import org.json.simple.JSONObject;

public class CustomerJson {
	
	private JSONObject customerJson;

	public JSONObject getCustomerJson() {
		return customerJson;
	}

	public void setCustomerJson(JSONObject customerJson) {
		this.customerJson = customerJson;
	}

}
